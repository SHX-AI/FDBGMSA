class Config(object):
    def __init__(self):
        self.kg_embedding_dim = 300
        self.batch_size = 32
        self.max_visual_len = 100
        self.max_audio_len = 150
        self.max_text_len = 25
        # self.epoch_num = 15
        self.epoch_num = 15
        self.hidden_dim = 300
        self.att_dim = 300
        self.class_num =3
        self.dropout = 0.7
        self.learning_rate = 0.001
        self.miss_rate = 0.6
        self.mem_size = 32

        self.mem_len = 150
        self.embedding_dim = 300
        self.warmup_steps=1077
        # self.dropout = 0.8
        # self.learning_rate = 0.001
        # self.miss_rate = 0.5


# - `batch_size`：批处理的大小，即一次训练中同时处理的样本数量。
# - `max_visual_len`：视觉输入的最大长度，通常是图像或视频帧序列的最大帧数。
# - `max_audio_len`：音频输入的最大长度，通常是音频序列的最大采样数。
# - `max_text_len`：文本输入的最大长度，通常是文本序列的最大单词数或字符数。
# - `epoch_num`：训练的轮数，即整个数据集被遍历的次数。
# - `hidden_dim`：隐藏层的维度，即神经网络中隐藏层神经元的数量。
# - `att_dim`：注意力机制的维度，即在注意力模型中用于计算注意力权重的神经元数量。
# - `class_num`：分类的类别数，即模型输出的类别数量。
# - `dropout`：dropout 的比例，用于控制神经网络中的过拟合。
# - `learning_rate`：学习率，即优化算法中用于控制参数更新步长的参数。
# - `miss_rate`：误判率，用于指示数据集中被误分类的比例。

