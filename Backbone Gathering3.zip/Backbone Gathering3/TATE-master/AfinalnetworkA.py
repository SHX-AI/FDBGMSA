import tensorflow as tf
import tensorflow.contrib.rnn as rnn
import numpy as np
from Settings import Config
from module import *
import sys
from tensorflow.python.keras.utils import losses_utils
from tensorflow.python.keras.layers import *





class MM:
    def __init__(self, is_training):

        def ln(inputs, epsilon=1e-8, scope="ln", trainable=True):
            """层归一化"""
            with tf.variable_scope(scope):
                inputs_shape = inputs.get_shape()
                params_shape = inputs_shape[-1:]

                mean, variance = tf.nn.moments(inputs, [-1], keepdims=True)
                beta = tf.get_variable("beta", params_shape, initializer=tf.zeros_initializer(), trainable=trainable)
                gamma = tf.get_variable("gamma", params_shape, initializer=tf.ones_initializer(), trainable=trainable)

                normalized = (inputs - mean) / ((variance + epsilon) ** 0.5)
                outputs = gamma * normalized + beta

            return outputs

        def scaled_dot_product_attention(Q, K, V, causality=False, dropout_rate=0.0, training=True):
            """缩放点积注意力机制"""
            d_k = K.get_shape().as_list()[-1]
            with tf.name_scope("scaled_dot_product_attention"):
                # 计算 QK^T，然后除以 d_k 的平方根
                outputs = tf.matmul(Q, K, transpose_b=True)  # (N, T_q, T_k)
                outputs = outputs / tf.sqrt(tf.cast(d_k, tf.float32))


                if causality:
                    outputs = tf.matrix_band_part(outputs, -1, 0)  # (N, T_q, T_k)

                # 应用softmax
                outputs = tf.nn.softmax(outputs)

                # 应用dropout
                if dropout_rate > 0 and training:
                    outputs = tf.nn.dropout(outputs, rate=dropout_rate)

                # 计算 QK^T V
                outputs = tf.matmul(outputs, V)  # (N, T_q, d_v)

            return outputs

        def multihead_attention(queries, keys, num_heads, dropout_rate=0.2, training=True, causality=False,
                                scope="multihead_attention"):
            d_model = queries.get_shape().as_list()[-1]
            with tf.variable_scope(scope):
                # Linear projections
                Q = tf.layers.dense(queries, d_model, use_bias=False)  # (N, T_q, d_model)
                K = tf.layers.dense(keys, d_model, use_bias=False)  # (N, T_k, d_model)
                V = K  # (N, T_k, d_model)

                # Split and concat
                Q_ = tf.concat(tf.split(Q, num_heads, axis=2), axis=0)  # (h*N, T_q, d_model/h)
                K_ = tf.concat(tf.split(K, num_heads, axis=2), axis=0)  # (h*N, T_k, d_model/h)
                V_ = K_  # (h*N, T_k, d_model/h)

                # Attention
                outputs = scaled_dot_product_attention(Q_, K_, V_, causality, dropout_rate, training)

                # Restore shape
                outputs = tf.concat(tf.split(outputs, num_heads, axis=0), axis=2)  # (N, T_q, d_model)

                # Residual connection
                outputs += queries

                # Normalize
                outputs = ln(outputs)

            return outputs

        def adaptive_combination(attention_outputs, scope="adaptive_combination"):
            """自适应结合不同的注意力输出"""
            num_layers = len(attention_outputs)
            d_model = attention_outputs[0].get_shape().as_list()[-1]

            with tf.variable_scope(scope):
                # 初始化权重
                weights = tf.get_variable("combination_weights", [num_layers], initializer=tf.ones_initializer(),
                                          trainable=True)
                weights = tf.nn.softmax(weights)  # 使得权重和为1

                # 将权重应用到每一层的输出
                combined_output = tf.add_n([weights[i] * attention_outputs[i] for i in range(num_layers)])

            return combined_output

        def pyramid_multihead_attention(queries, keys, dropout_rate=0.2, training=True, causality=False,
                                        scope="pyramid_multihead_attention"):
            attention_outputs = []

            with tf.variable_scope(scope):
                # 第一层：2个头
                with tf.variable_scope("layer_0"):
                    outputs = multihead_attention(queries=queries, keys=keys, num_heads=2,
                                                  dropout_rate=dropout_rate, training=training, causality=causality,
                                                  scope="attention_0")
                    attention_outputs.append(outputs)

                # 第二层：4个头
                with tf.variable_scope("layer_1"):
                    outputs = multihead_attention(queries=outputs, keys=keys, num_heads=4,
                                                  dropout_rate=dropout_rate, training=training, causality=causality,
                                                  scope="attention_1")
                    attention_outputs.append(outputs)

                # 第三层：6个头
                with tf.variable_scope("layer_2"):
                    outputs = multihead_attention(queries=outputs, keys=keys, num_heads=6,
                                                  dropout_rate=dropout_rate, training=training, causality=causality,
                                                  scope="attention_2")
                    attention_outputs.append(outputs)

                # 自适应结合不同层的输出
                final_output = adaptive_combination(attention_outputs)

            return final_output

        # 自注意力和前馈网络
        def apply_attention_and_ff(modality, scope_name):
            with tf.variable_scope(scope_name, reuse=tf.AUTO_REUSE):
                modality = multihead_attention(queries=modality, keys=modality, num_heads=4,
                                               dropout_rate=0.2, training=is_training, causality=False)
                modality = ff(modality, num_units=[4 * self.att_dim, self.att_dim])
            return modality

        self.config = Config()
        self.att_dim = self.config.att_dim


        self.visual = tf.placeholder(dtype=tf.float32, shape=[self.config.batch_size, self.config.max_visual_len, 709],
                                     name='visual')
        self.audio = tf.placeholder(dtype=tf.float32, shape=[self.config.batch_size, self.config.max_audio_len, 33],
                                    name='audio')
        self.text = tf.placeholder(dtype=tf.float32, shape=[self.config.batch_size, self.config.max_text_len, 768],
                                   name='text')

        self.label = tf.placeholder(dtype=tf.int32, shape=[self.config.batch_size], name='label')
        self.flag = tf.placeholder(dtype=tf.float32, shape=[self.config.batch_size], name='flag')

        # 处理各模态特征
        visual = tf.layers.dense(self.visual, self.att_dim, use_bias=False, name='visual_dense')
        audio = tf.layers.dense(self.audio, self.att_dim, use_bias=False, name='audio_dense')
        text = tf.layers.dense(self.text, self.att_dim, use_bias=False, name='text_dense')

        # 拼接融合三个模态的特征
        enc_concat = tf.concat([visual, audio, text], axis=1)

        # 对融合特征应用多头自注意力机制
        enc_concat = pyramid_multihead_attention(queries=enc_concat, keys=enc_concat,
                                                 dropout_rate=0.2, training=is_training, causality=False)

        # 融合分离
        with tf.variable_scope('decoupling'):
            enc_vv1 = tf.layers.dense(enc_concat, self.att_dim, use_bias=False, name='decoupling_vv')
            enc_vv1 = enc_vv1[:, :self.config.max_visual_len, :]
            enc_vv = tf.concat([visual, enc_vv1], axis=1)

            enc_aa1 = tf.layers.dense(enc_concat, self.att_dim, use_bias=False, name='decoupling_aa')
            enc_aa1 = enc_aa1[:, self.config.max_visual_len:self.config.max_visual_len + self.config.max_audio_len, :]
            enc_aa = tf.concat([audio, enc_aa1], axis=1)

            enc_tt1 = tf.layers.dense(enc_concat, self.att_dim, use_bias=False, name='decoupling_tt')
            enc_tt1 = enc_tt1[:, self.config.max_visual_len + self.config.max_audio_len:, :]
            enc_tt = tf.concat([text, enc_tt1], axis=1)




        def truncate_sequence(sequence, target_length, attention_dim=300):
            sequence_length = sequence.get_shape().as_list()[1]
            if sequence_length <= target_length:
                return sequence


            with tf.variable_scope('attention_truncate', reuse=tf.AUTO_REUSE):
                attention_w = tf.get_variable('attention_w', [self.config.att_dim, attention_dim])
                attention_b = tf.get_variable('attention_b', [attention_dim])
                u = tf.tanh(tf.tensordot(sequence, attention_w, axes=[[2], [0]]) + attention_b)  # (N, T, attention_dim)

                attention_v = tf.get_variable('attention_v', [attention_dim])
                scores = tf.tensordot(u, attention_v, axes=[[2], [0]])  # (N, T)
                scores = tf.nn.softmax(scores, axis=1)


                truncated_sequence = tf.slice(sequence, [0, target_length, 0],
                                              [-1, sequence_length - target_length, -1])
                weighted_truncated_sequence = tf.reduce_sum(
                    truncated_sequence * tf.expand_dims(scores[:, target_length:], axis=-1), axis=1, keepdims=True)
                weighted_truncated_sequence = tf.tile(weighted_truncated_sequence, [1, target_length, 1])


                retained_sequence = tf.slice(sequence, [0, 0, 0], [-1, target_length, -1])
                truncated_sequence = tf.concat([retained_sequence, weighted_truncated_sequence], axis=1)
                truncated_sequence = tf.slice(truncated_sequence, [0, 0, 0], [-1, target_length, -1])

            return truncated_sequence


        enc_vv = apply_attention_and_ff(enc_vv, 'vv')

        enc_aa = apply_attention_and_ff(enc_aa, 'aa')

        enc_tt = apply_attention_and_ff(enc_tt, 'tt')


        enc_tt = truncate_sequence(enc_tt, 25)

        enc_aa = truncate_sequence(enc_aa, 25)

        enc_vv = truncate_sequence(enc_vv, 25)



        enc_aa1=enc_aa



        with tf.variable_scope('av', reuse=tf.AUTO_REUSE):
            av = pyramid_multihead_attention(queries=enc_vv, keys=enc_aa1, dropout_rate=0.2,
                                             training=True, causality=False)

            av = ff(av, num_units=[4 * self.config.att_dim, self.config.att_dim])

            avv1 = tf.concat([enc_vv, av], axis=1)
            enc_vv1 = apply_attention_and_ff(avv1, 'avv1')

            enc_vv1 = truncate_sequence(enc_vv1, enc_tt.get_shape().as_list()[1])




        with tf.variable_scope('dva', reuse=tf.AUTO_REUSE):
            dec_dva = pyramid_multihead_attention(queries=enc_aa1, keys=enc_vv1,
                                                  dropout_rate=0.2, training=True, causality=False)
            dec_dva = ff(dec_dva, num_units=[4 * self.config.att_dim, self.config.att_dim])


        with tf.variable_scope('at', reuse=tf.AUTO_REUSE):
            at = pyramid_multihead_attention(queries=enc_tt, keys=enc_aa1, dropout_rate=0.2,
                                             training=True, causality=False)

            at = ff(at, num_units=[4 * self.config.att_dim, self.config.att_dim])

            att1 = tf.concat([enc_tt, at], axis=1)

        enc_tt1 = apply_attention_and_ff(att1, "att1")

        enc_tt1 = truncate_sequence(enc_tt1, enc_tt.get_shape().as_list()[1])


        with tf.variable_scope('dta', reuse=tf.AUTO_REUSE):
            dec_dta = pyramid_multihead_attention(queries=enc_aa1, keys=enc_tt1, dropout_rate=0.2, training=True,
                                                  causality=False)
            dec_dta = ff(dec_dta, num_units=[4 * self.config.att_dim, self.config.att_dim])

        enc_all = tf.concat([enc_aa1, dec_dva, dec_dta], axis=1)

        enc_final1 = apply_attention_and_ff(enc_all, 'enc_all')


        with tf.variable_scope('output_layer', reuse=tf.AUTO_REUSE):
            enc_final_flat = tf.layers.flatten(enc_final1)
            logits = tf.layers.dense(enc_final_flat, self.config.class_num)

        self.prob = tf.nn.softmax(logits)

        with tf.name_scope('loss'):
            ouput_label = tf.one_hot(self.label, self.config.class_num)
            self.loss = tf.reduce_sum(tf.nn.softmax_cross_entropy_with_logits(logits=logits, labels=ouput_label))


            weights_list = tf.trainable_variables()
            self.l2_loss = tf.contrib.layers.apply_regularization(
                regularizer=tf.contrib.layers.l2_regularizer(0.0001),
                weights_list=weights_list
            )

            self.total_loss = self.loss + self.l2_loss

