import tensorflow as tf
import os
import datetime
import numpy as np
from numpy import VisibleDeprecationWarning

from Settings import Config
from Dataset import Dataset
from AfinalnetworkA import MM
import pickle
from sklearn.metrics import f1_score
from sklearn.metrics import accuracy_score
import logging
import threading
import queue
import datetime
import time
import gc
import time


from module import *
from collections import OrderedDict
from scipy.sparse import csr_matrix

from sklearn.metrics.pairwise import cosine_similarity
import warnings
#警告删除，如果需要可以删掉查看

warnings.filterwarnings("ignore", category=FutureWarning)

logging.getLogger('tensorflow').disabled = True

os.environ['CUDA_VISIBLE_DEVICES'] = '0,1'
FLAGS = tf.app.flags.FLAGS

tf.app.flags.DEFINE_boolean('train',True, 'set True to train')
# 第三篇############################################

from sklearn.metrics.pairwise import cosine_similarity



traindata = pickle.load(open('E:\dataset\meld/3/train3.pkl', 'rb'))
testdata = pickle.load(open('E:\\dataset\\meld\\3/m24test3-0.5-defect.pkl', 'rb'))

#2-5
print("先看settings改没改")
def evaluation(y_pred, y_true):
    f1_s = f1_score(y_true, y_pred, average='macro')
    accuracy_s = accuracy_score(y_true, y_pred)
    return f1_s, accuracy_s
def is_equal(a, b):
    flag = 1
    for i in range(len(a)):
        if a[i] != b[i]:
            flag = 0
            break
    return flag
#加入平滑机制
class DynamicWarmupScheduler:
    def __init__(self, initial_warmup_steps, learning_rate_base, patience, improvement_threshold=0.01,
                 decay_factor=0.9, increase_factor=1.0, min_warmup_steps=1077, smoothing=0.05):
        self.initial_warmup_steps = min(initial_warmup_steps, 77777)
        self.learning_rate_base = learning_rate_base
        self.patience = patience
        self.improvement_threshold = improvement_threshold
        self.decay_factor = decay_factor
        self.increase_factor = increase_factor
        self.min_warmup_steps = min_warmup_steps
        self.best_loss = float('inf')
        self.no_improvement_steps = 0
        self.smoothing = smoothing
        self.smoothed_loss = None

    def get_learning_rate(self, global_step):
        learning_rate = self.learning_rate_base * tf.minimum(1.0, tf.cast(global_step / self.initial_warmup_steps, tf.float32))
        return learning_rate

    def update(self, current_loss, global_step):
        if self.smoothed_loss is None:
            self.smoothed_loss = current_loss
        else:
            self.smoothed_loss = self.smoothing * current_loss + (1 - self.smoothing) * self.smoothed_loss

        if self.smoothed_loss < self.best_loss * (1 - self.improvement_threshold):
            self.best_loss = self.smoothed_loss
            self.no_improvement_steps = 0
            self.initial_warmup_steps = max(int(self.initial_warmup_steps * self.decay_factor), self.min_warmup_steps)
            self.initial_warmup_steps = min(self.initial_warmup_steps, 77777)
            print("Reduced warmup steps to:", self.initial_warmup_steps)
        else:
            self.no_improvement_steps += 1

            if self.no_improvement_steps >= self.patience:
                self.initial_warmup_steps = int(self.initial_warmup_steps * self.increase_factor)
                self.initial_warmup_steps = min(self.initial_warmup_steps, 77777)
                print("Increased warmup steps to:", self.initial_warmup_steps)
                self.no_improvement_steps = 0
# 学习率预热函数定义
def learning_rate_warmup(learning_rate_base, global_step, warmup_steps):
    return learning_rate_base * tf.minimum(1.0, tf.cast(global_step / warmup_steps, tf.float32))
class AdamWOptimizer(tf.train.Optimizer):
    def __init__(self, learning_rate, weight_decay, use_locking=False, name="AdamW"):
        super(AdamWOptimizer, self).__init__(use_locking, name)
        self._learning_rate = learning_rate
        self._weight_decay = weight_decay

    def _apply_dense(self, grad, var):
        grad_with_decay = grad + self._weight_decay * var
        return tf.train.AdamOptimizer(self._learning_rate).apply_gradients([(grad_with_decay, var)])

    def _apply_sparse(self, grad, var):
        grad_with_decay = grad + self._weight_decay * var
        return tf.train.AdamOptimizer(self._learning_rate).apply_gradients([(grad_with_decay, var)])








def cosine_similarity(a, b):
    a = np.array(a, dtype=np.float32)
    b = np.array(b, dtype=np.float32)

    if a.ndim == 1:
        a = a.reshape(1, -1)
    if b.ndim == 1:
        b = b.reshape(1, -1)
    elif b.ndim == 3:
        b = b.reshape(b.shape[0], -1)

    if a.shape[-1] != b.shape[-1]:
        raise ValueError(f"Shapes {a.shape} and {b.shape} not aligned: {a.shape[-1]} != {b.shape[-1]}")

    dot_product = np.dot(a, b.T)
    norm_a = np.linalg.norm(a, axis=1)
    norm_b = np.linalg.norm(b, axis=1)

    norm_a = np.where(norm_a == 0, 1e-10, norm_a)
    norm_b = np.where(norm_b == 0, 1e-10, norm_b)

    cosine_sim = dot_product / (norm_a[:, None] * norm_b)
    return cosine_sim.flatten()








import numpy as np
import tensorflow as tf
from datetime import datetime
import gc
from sklearn.metrics.pairwise import cosine_similarity

def adaptive_weights(similarities):
    if len(similarities) == 0:
        return []

    # 将相似度转化成权重
    weights = np.exp(similarities) / np.sum(np.exp(similarities))
    # print("adaptive_weights---success")
    # print(weights.shape)
    return weights


# 层归一化
def ln(inputs, epsilon=1e-8):
    mean = np.mean(inputs, axis=-1, keepdims=True)
    variance = np.var(inputs, axis=-1, keepdims=True)
    normalized = (inputs - mean) / np.sqrt(variance + epsilon)
    beta = np.zeros(inputs.shape[-1:])
    gamma = np.ones(inputs.shape[-1:])
    outputs = gamma * normalized + beta
    return outputs

# 缩放点积注意力机制
def scaled_dot_product_attention_numpy(Q, K, V, causality=False, dropout_rate=0.0):
    d_k = K.shape[-1]
    outputs = np.dot(Q, K.T) / np.sqrt(d_k)

    if causality:
        diag_vals = np.ones_like(outputs[0])
        tril = np.tril(diag_vals)
        outputs = outputs * tril

    outputs = np.exp(outputs - outputs.max(axis=-1, keepdims=True))
    outputs = outputs / np.sum(outputs, axis=-1, keepdims=True)

    if dropout_rate > 0:
        dropout_mask = (np.random.rand(*outputs.shape) > dropout_rate).astype(np.float32)
        outputs = outputs * dropout_mask

    outputs = np.dot(outputs, V)
    return outputs

# 填充输入数据
def pad_input_data(data, lcm_dim):
    current_dim = data.shape[-1]
    padding_size = (lcm_dim - current_dim % lcm_dim) if current_dim % lcm_dim != 0 else 0
    if padding_size:
        padding = np.zeros((data.shape[0], padding_size), dtype=data.dtype)
        data = np.concatenate([data, padding], axis=1)
    return data

# 多头注意力机制，使用 NumPy
def multihead_attention_numpy(queries, keys, num_heads, dropout_rate=0.2,
                             causality=False, scope="multihead_attention"):
    # 填充输入数据
    lcm_dim = 12  # 选择12作为最小公倍数
    queries = pad_input_data(queries, lcm_dim)
    keys = pad_input_data(keys, lcm_dim)

    d_model = queries.shape[-1]

    # 初始化权重矩阵
    W_Q = np.random.randn(d_model, d_model)
    W_K = np.random.randn(d_model, d_model)
    W_V = np.random.randn(d_model, d_model)

    # 线性投影
    Q = np.dot(queries, W_Q)  # (N, T_q, d_model)
    K = np.dot(keys, W_K)    # (N, T_k, d_model)
    V = np.dot(K, W_V)       # (N, T_k, d_model)

    # 分割
    Q_split = np.array_split(Q, num_heads, axis=-1)  # List of [N, T_q, d_model/h]
    K_split = np.array_split(K, num_heads, axis=-1)  # List of [N, T_k, d_model/h]
    V_split = np.array_split(V, num_heads, axis=-1)  # List of [N, T_k, d_model/h]

    attention_heads = []
    for q, k, v in zip(Q_split, K_split, V_split):
        attention_head = scaled_dot_product_attention_numpy(q, k, v, causality, dropout_rate)
        attention_heads.append(attention_head)

    # 拼接所有注意力头的结果
    outputs = np.concatenate(attention_heads, axis=-1)  # (N, T_q, d_model)

    # 残差连接
    outputs += queries

    # 层归一化
    outputs = ln(outputs)

    return outputs

# 金字塔多头注意力机制，使用 NumPy
def pyramid_multihead_attention(queries, keys, dropout_rate=0.2,
                                     training=True, causality=False, scope="pyramid_multihead_attention"):
    attention_outputs = []

    # 第一层：2个头
    with np.errstate(invalid='ignore', divide='ignore'):
        outputs = multihead_attention_numpy(queries=queries, keys=keys, num_heads=2,
                                            dropout_rate=dropout_rate, causality=causality,
                                            scope="attention_0")
        attention_outputs.append(outputs)

    # 第二层：4个头
    outputs = multihead_attention_numpy(queries=outputs, keys=keys, num_heads=4,
                                        dropout_rate=dropout_rate, causality=causality,
                                        scope="attention_1")
    attention_outputs.append(outputs)

    # 第三层：6个头
    outputs = multihead_attention_numpy(queries=outputs, keys=keys, num_heads=6,
                                        dropout_rate=dropout_rate, causality=causality,
                                        scope="attention_2")
    attention_outputs.append(outputs)

    # 自适应结合不同层的输出
    final_output = adaptive_combination_numpy(attention_outputs)

    return final_output

# 自适应结合不同的注意力输出
def adaptive_combination_numpy(attention_outputs):
    num_layers = len(attention_outputs)
    d_model = attention_outputs[0].shape[-1]

    # 初始化权重
    weights = np.random.rand(num_layers)
    weights = weights / np.sum(weights)  # 使得权重和为1

    # 将权重应用到每一层的输出
    combined_output = np.zeros_like(attention_outputs[0])
    for i in range(num_layers):
        combined_output += weights[i] * attention_outputs[i]

    return combined_output


def softmax(x):
    """ 手动实现 softmax 函数 """
    e_x = np.exp(x - np.max(x, axis=-1, keepdims=True))
    return e_x / np.sum(e_x, axis=-1, keepdims=True)
import warnings
warnings.filterwarnings("ignore", category=VisibleDeprecationWarning)

def select_similar_samples_in_window(batch_data, current_index, top_k=2, threshold=0.90):
    """
    从当前批次中选择相似样本的索引。

    :param batch_data: 当前批次的所有数据。
    :param current_index: 当前样本的索引。
    :param top_k: 选择的相似样本数量。
    :param threshold: 相似度阈值。
    :return: 返回两个相似样本的索引。
    """

    current_sample = batch_data[current_index]



    historical_indices = list(range(max(0, current_index - 10), current_index))

    if current_index < 10:  # 如果当前索引小于10，没有足够的参考的历史样本，跳过

        return None, None

    historical_samples = batch_data[historical_indices]

    if not historical_samples.size > 0:
        # print("not historical_samples.size > 0")
        return None, None



    # 确保 historical_samples 是一个三维数组，并且每个历史样本是二维数组
    historical_samples = np.array(historical_samples, dtype=np.float32)
    # print(f"historical_samples after np.array: shape = {historical_samples.shape}, ndim = {historical_samples.ndim}")

    if historical_samples.ndim != 3:
        # print("historical_samples.ndim != 3")
        return None, None

    if historical_samples.shape[1:] != current_sample.shape:
        # print(f"historical_samples.shape[1:] != current_sample.shape: {historical_samples.shape[1:]} != {current_sample.shape}")
        return None, None

    # 逐个计算相似度
    similarities = []
    for historical_sample in historical_samples:
        historical_sample_reshaped = historical_sample.reshape(1, -1)  # 确保 historical_sample 是二维数组
        similarity = cosine_similarity(current_sample.reshape(1, -1), historical_sample_reshaped)[0][0]
        similarities.append(similarity)

    similarities = np.array(similarities)
    # print(f"similarities shape: {similarities.shape}")

    valid_indices = np.where((similarities <= 0.95) & (similarities >= threshold))[0]  # 注意索引位置
    # print(f"valid_indices: {valid_indices}")

    if len(valid_indices) == 0:
        # print("len(valid_indices) == 0")
        return None, None

    # 按相似度排序并选择前 top_k 个样本的索引
    sorted_indices = np.argsort(similarities[valid_indices])[-top_k:][::-1]
    sorted_indices = valid_indices[sorted_indices]
    # print(f"sorted_indices: {sorted_indices}")

    if len(sorted_indices) < 2:
        # print("Not enough similar samples found.")
        return None, None

    return sorted_indices[0], sorted_indices[1]

def train(sess, setting):
    total_steps = 1810  # 预设的总步数
    initial_training_steps = 3000

    dynamic_scheduler = DynamicWarmupScheduler(
        initial_warmup_steps=setting.warmup_steps,
        learning_rate_base=setting.learning_rate,
        patience=10
    )

    config = tf.ConfigProto()
    config.gpu_options.allow_growth = True
    config.gpu_options.per_process_gpu_memory_fraction = 0.9

    with tf.Session(config=config) as sess:
        dataset = Dataset()

        initializer = tf.contrib.layers.xavier_initializer()

        with tf.variable_scope('model', reuse=None, initializer=initializer):
            # print("数据集加载完成")
            m = MM(is_training=True)

        global_step = tf.Variable(0, name='global_step', trainable=False)
        learning_rate = dynamic_scheduler.get_learning_rate(global_step)
        optimizer = AdamWOptimizer(learning_rate, weight_decay=0.01)
        train_op = optimizer.minimize(m.total_loss, global_step=global_step)

        sess.run(tf.global_variables_initializer())

        var_list = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope='model')
        saver = tf.train.Saver(var_list=var_list)

        online_learning_vars = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope='online_learning')
        sess.run(tf.variables_initializer(online_learning_vars))

        print("开始训练")

        for epoch in range(setting.epoch_num):  # 循环所有的epoch
            for i in range(int(len(traindata['L']) / setting.batch_size)):
                current_step = epoch * int(len(traindata['L']) / setting.batch_size) + i
                if current_step >= total_steps:
                    print("达到预设的总步数，结束训练。")
                    return  # 结束训练

                cur_batch = dataset.nextBatch(traindata, testdata, True)

                # # 调试信息：检查 cur_batch 的数据类型和形状
                # for modality in ['V', 'A', 'T']:
                #     print(f"cur_batch[{modality}] shape: {cur_batch[modality].shape}, type: {type(cur_batch[modality])}")
                #     print(f"cur_batch[{modality}] dtype: {cur_batch[modality].dtype}")

                batch_with_historical = {
                    'V': [],
                    'A': [],
                    'T': []
                }

                # 检查是否需要进行先验增强
                if current_step > 0:
                    for j in range(setting.batch_size):
                        current_sample = {modality: np.array(cur_batch[modality][j], dtype=np.float32) for modality in ['V', 'A', 'T']}

                        # 先验增强
                        similar_indices = {}
                        for modality in ['V', 'A', 'T']:
                            index1, index2 = select_similar_samples_in_window(
                                np.array(cur_batch[modality], dtype=np.float32),
                                current_index=j,
                                threshold=0.90
                            )
                            # print(f"选择结束: index1={index1}, index2={index2}")
                            similar_indices[modality] = (index1, index2)
                        if any(idx is not None for idx in similar_indices.values()):
                            fused_data = {}
                            for modality in ['V', 'A', 'T']:
                                index1, index2 = similar_indices[modality]
                                if index1 is not None and index2 is not None:

                                    similar_sample1 = np.array(cur_batch[modality][index1], dtype=np.float32)
                                    similar_sample2 = np.array(cur_batch[modality][index2], dtype=np.float32)

                                    # 检查数据类型和形状
                                    # print(f"current_sample[{modality}] shape: {current_sample[modality].shape}, type: {type(current_sample[modality])}, dtype: {current_sample[modality].dtype}")
                                    # print(f"similar_sample1 shape: {similar_sample1.shape}, type: {type(similar_sample1)}, dtype: {similar_sample1.dtype}")
                                    # print(f"similar_sample2 shape: {similar_sample2.shape}, type: {type(similar_sample2)}, dtype: {similar_sample2.dtype}")

                                    attention_output1 = pyramid_multihead_attention(
                                        queries=current_sample[modality],
                                        keys=similar_sample1,
                                        dropout_rate=0.2,
                                        training=True,
                                        causality=False
                                    )
                                    # print("第一个结束")

                                    attention_output2 = pyramid_multihead_attention(
                                        queries=current_sample[modality],
                                        keys=similar_sample2,
                                        dropout_rate=0.2,
                                        training=True,
                                        causality=False
                                    )
                                    # print("第二个结束")

                                    # print(attention_output1)

                                    attention_weights1 = softmax(attention_output1)
                                    # print("attention_weights1:",attention_weights1)
                                    attention_weights2 = softmax(attention_output2)
                                    # print("attention_weights2:",attention_weights2)
                                    # attention_weights1=sess.run(attention_weights1)
                                    # print(attention_weights1)

                                    # 对 attention_weights1 和 attention_weights2 取平均
                                    # attention_weights1_avg = np.mean(attention_weights1)
                                    # print("attention_weights1_avg:", attention_weights1_avg)
                                    # attention_weights2_avg = np.mean(attention_weights2)
                                    # print("attention_weights2_avg:", attention_weights2_avg)

                                    # 计算中位数
            ##### ####### #Author： 我们发现使用平均值不能很好的体现各个特征的权重值，和Softmax的作用， 所以我们在这里进行了更新，使用中位数，最优的结果还是和论文一样，只是效果可以更稳定，平均效果好一点点，大家可以根据自己需要选择。
                     #######We found that using the average value does not effectively reflect the weight values of each feature and the function of Softmax.
                        # Therefore, we have made an update here and used the median instead.
                                    # The optimal result is still the same as that in the paper, but the effect is more stable and the average effect is slightly better.
                                    # You can choose according to your own needs.
                                    attention_weights1_median = np.median(attention_weights1)
                                    # print("attention_weights1_median:", attention_weights1_median)
                                    attention_weights2_median = np.median(attention_weights2)
                                    # print("attention_weights2_median:", attention_weights2_median)

                                    # attention_weights2 = tf.nn.softmax(attention_output2)


                                    # cos_sim_1 = cosine_similarity(current_sample[modality].reshape(1, -1), similar_sample1.reshape(1, -1))[0][0]
                                    # cos_sim_2 = cosine_similarity(current_sample[modality].reshape(1, -1), similar_sample2.reshape(1, -1))[0][0]
                                    # print(f"cos_sim_1: {cos_sim_1}, type: {type(cos_sim_1)}, dtype: {cos_sim_1.dtype}")
                                    # print(f"cos_sim_2: {cos_sim_2}, type: {type(cos_sim_2)}, dtype: {cos_sim_2.dtype}")

                                    similarities = []
                                    similarities.append(1.0)
                                    # similarities.append(attention_weights1_avg)
                                    # similarities.append(attention_weights2_avg)
                                    similarities.append(attention_weights1_median)
                                    similarities.append(attention_weights2_median)

                                    # print("similar_sample1 end")
                                    # print("similar_samplesssssss end")
                                    weights = adaptive_weights(similarities)
                                    # print("adaptive_weights end")

                                    # 检查权重
                                    # print(f"weights shape: {weights.shape}, type: {type(weights)}, dtype: {weights.dtype}")

                                    current_sample[modality] = np.array(current_sample[modality], dtype=np.float32)
                                    similar_sample1 = np.array(similar_sample1, dtype=np.float32)
                                    similar_sample2 = np.array(similar_sample2, dtype=np.float32)
                                    weights = np.array(weights, dtype=np.float32)

                                    # # 调试信息：确保所有变量都是 NumPy 数组并且 dtype 是 float32
                                    # print(f"weights type: {type(weights)}, dtype: {weights.dtype}")
                                    # print(f"current_sample[{modality}] type: {type(current_sample[modality])}, dtype: {current_sample[modality].dtype}")
                                    # print(f"similar_sample1 type: {type(similar_sample1)}, dtype: {similar_sample1.dtype}")
                                    # print(f"similar_sample2 type: {type(similar_sample2)}, dtype: {similar_sample2.dtype}")

                                    fused_data[modality] = (
                                            weights[0] * current_sample[modality] +
                                            weights[1] * similar_sample1 +
                                            weights[2] * similar_sample2
                                    )

                                    # print(f"fused_data[{modality}] shape after fusion: {fused_data[modality].shape}")
                                else:
                                    fused_data[modality] = np.array(current_sample[modality], dtype=np.float32)
                                    # print(f"fused_data[{modality}] no similar samples, using current_sample")
                        else:
                            fused_data = {modality: np.array(current_sample[modality], dtype=np.float32) for modality in ['V', 'A', 'T']}
                            # print(f"fused_data no similar samples for modality {modality}, using current_sample")

                        for modality in ['V', 'A', 'T']:
                            batch_with_historical[modality].append(fused_data[modality])
                            # print(f"batch_with_historical[{modality}] appended, shape: {np.array(batch_with_historical[modality]).shape}")
                else:
                    # 不进行先验增强，直接使用原始样本
                    for j in range(setting.batch_size):
                        current_sample = {modality: np.array(cur_batch[modality][j], dtype=np.float32) for modality in ['V', 'A', 'T']}
                        for modality in ['V', 'A', 'T']:
                            batch_with_historical[modality].append(current_sample[modality])
                            # print(f"batch_with_historical[{modality}] appended, shape: {np.array(batch_with_historical[modality]).shape}")

                for modality in ['V', 'A', 'T']:
                    cur_batch[modality] = np.array(batch_with_historical[modality], dtype=np.float32)
                    # print(f"cur_batch[{modality}] shape after processing: {cur_batch[modality].shape}")

                feed_dict = {
                    m.visual: cur_batch['V'],
                    m.audio: cur_batch['A'],
                    m.text: cur_batch['T'],
                    m.label: cur_batch['L'],
                    m.flag: np.ones(setting.batch_size)
                }

                try:
                    if current_step < initial_training_steps:
                        _, loss_ = sess.run([train_op, m.total_loss], feed_dict)
                    else:
                        _, loss_ = sess.run([train_op, m.total_loss], feed_dict)

                    dynamic_scheduler.update(loss_, current_step)

                    if current_step % 10 == 0:
                        time_str = datetime.now().isoformat()
                        print(f"{time_str}: step {current_step}, loss {loss_}")

                        saver_all = tf.train.Saver(max_to_keep=None)
                        saver_all.save(sess, './final/MT_ATT_model', global_step=current_step)
                        gc.collect()

                except tf.errors.ResourceExhaustedError:
                    print("内存不足，尝试清理缓存并继续...")
                    gc.collect()
                    continue

        print("训练完成")

import time
import gc
import tensorflow as tf
from datetime import datetime

#正常训练不输出时间和内存
def test(sess, setting):
    dataset = Dataset()
    with sess.as_default():
        with tf.variable_scope('model', reuse=tf.AUTO_REUSE):
            mtest = MM(is_training=False)

        saver = tf.train.Saver()
        testlist = range(1000, 2000, 10)
        # testlist = range(300, 1880, 10)
        best_model_iter = -1
        best_model_f1 = -1
        best_model_acc = -1

        all_f1 = []
        all_acc = []

        for model_iter in testlist:
            try:
                saver.restore(sess, './final/MT_ATT_model-' + str(model_iter))
            except tf.errors.NotFoundError:
                print(f"Model at iteration {model_iter} not found, skipping.")
                continue

            total_pred = []
            total_y = []

            num_batches = int(len(testdata['L']) / setting.batch_size)
            for i in range(num_batches):
                try:
                    cur_batch = dataset.nextBatch(traindata, testdata, FLAGS.train)

                    feed_dict = {
                        mtest.visual: cur_batch['V'],
                        mtest.audio: cur_batch['A'],
                        mtest.text: cur_batch['T'],
                        mtest.label: cur_batch['L'],
                        mtest.flag: np.ones(setting.batch_size)
                    }

                    prob = sess.run(mtest.prob, feed_dict)

                    predicted_labels = np.argmax(prob, axis=1)

                    total_pred.extend(np.argmax(prob, axis=-1))
                    total_y.extend(cur_batch['L'])
                except Exception as e:

                    continue

            try:
                f1, accuracy = evaluation(total_pred, total_y)
            except Exception as e:

                continue

            with open(r'C:\Users\abc\Desktop\Final.txt', 'a') as file:
                all_f1.append(f1)
                all_acc.append(accuracy)

                if f1 > best_model_f1:
                    best_model_f1 = f1

                if accuracy > best_model_acc:
                    best_model_acc = accuracy
                    best_model_iter = model_iter

                time_str = datetime.now().isoformat()
                print(f"{time_str}")

                # 打印到控制台
                print('￥￥￥￥￥￥￥￥￥￥￥￥￥￥￥￥￥￥')
                print('model_iter:', model_iter)
                print('f1 score:', f1)
                print('accuracy score:', accuracy)
                print('￥￥￥￥￥￥￥￥￥￥￥￥￥￥￥￥￥￥')
                print('----------------------------')
                print('now best model_iter', best_model_iter)
                print('now best f1 score: ', best_model_f1)
                print('now best accuracy score:', best_model_acc)
                print('----------------------------')

                # 将相同的内容写入文件
                file.write('￥￥￥￥￥￥￥￥￥￥￥￥￥￥￥￥￥￥\n')
                file.write(f'model_iter: {model_iter}\n')
                file.write(f'f1 score: {f1}\n')
                file.write(f'accuracy score: {accuracy}\n')
                file.write('￥￥￥￥￥￥￥￥￥￥￥￥￥￥￥￥￥￥\n')
                file.write('----------------------------\n')
                file.write(f'now best model_iter {best_model_iter}\n')
                file.write(f'now best f1 score: {best_model_f1}\n')
                file.write(f'now best accuracy score: {best_model_acc}\n')
                file.write('----------------------------\n')

    return best_model_iter, best_model_f1, best_model_acc, all_f1, all_acc





def main(_):
    setting = Config()

    if FLAGS.train:
        # 训练部分，在独立的图上下文中
        with tf.Graph().as_default():
            config = tf.ConfigProto(allow_soft_placement=True)
            config.gpu_options.allow_growth = True
            with tf.Session(config=config) as sess:
                train(sess, setting)  # 训练模型

        # 训练完成后，我们重置默认图
        FLAGS.train = False  # 修改 FLAGS.train 的取值为 False

    # 在这里调用 tf.reset_default_graph() 是安全的，因为我们不在 `tf.Graph().as_default()` 的上下文中
    print("测试开始，上天保佑，结果如愿")
    tf.reset_default_graph()


    # 测试部分，也在独立的图上下文中
    with tf.Graph().as_default():
        config = tf.ConfigProto(allow_soft_placement=True)
        config.gpu_options.allow_growth = True
        with tf.Session(config=config) as sess:
            test(sess, setting)  # 运行测试相关的代码逻辑


# # ceshi 完成后，我们重置默认图
#     FLAGS.train = True  # 修改 FLAGS.train 的取值为 T
#
#     #在这里调用 tf.reset_default_graph() 是安全的，因为我们不在 `tf.Graph().as_default()` 的上下文中
#     tf.reset_default_graph()
#     print("*************第二轮训练开始*****************")
#     if FLAGS.train:
#         # 训练部分，在独立的图上下文中
#         with tf.Graph().as_default():
#             config = tf.ConfigProto(allow_soft_placement=True)
#             config.gpu_options.allow_growth = True
#             with tf.Session(config=config) as sess:
#                 train(sess, setting)  # 训练模型
#
#         # 训练完成后，我们重置默认图
#         FLAGS.train = False  # 修改 FLAGS.train 的取值为 False
#
#     # 在这里调用 tf.reset_default_graph() 是安全的，因为我们不在 `tf.Graph().as_default()` 的上下文中
#     tf.reset_default_graph()
#     print("第二轮测试开始，上天保佑，结果如愿")
#
#     # 测试部分，也在独立的图上下文中
#     with tf.Graph().as_default():
#         config = tf.ConfigProto(allow_soft_placement=True)
#         config.gpu_options.allow_growth = True
#         with tf.Session(config=config) as sess:
#             test(sess, setting)  # 运行测试相关的代码逻辑
#
# # ceshi 完成后，我们重置默认图
#     FLAGS.train = True  # 修改 FLAGS.train 的取值为 T
#
#     # 在这里调用 tf.reset_default_graph() 是安全的，因为我们不在 `tf.Graph().as_default()` 的上下文中
#     tf.reset_default_graph()
#     print("*************第三轮训练开始*****************")
#     if FLAGS.train:
#         # 训练部分，在独立的图上下文中
#         with tf.Graph().as_default():
#             config = tf.ConfigProto(allow_soft_placement=True)
#             config.gpu_options.allow_growth = True
#             with tf.Session(config=config) as sess:
#                 train(sess, setting)  # 训练模型
#
#         # 训练完成后，我们重置默认图
#         FLAGS.train = False  # 修改 FLAGS.train 的取值为 False
#
#     # 在这里调用 tf.reset_default_graph() 是安全的，因为我们不在 `tf.Graph().as_default()` 的上下文中
#     tf.reset_default_graph()
#     print("第三轮测试开始，上天保佑，结果如愿")
#
#     # 测试部分，也在独立的图上下文中
#     with tf.Graph().as_default():
#         config = tf.ConfigProto(allow_soft_placement=True)
#         config.gpu_options.allow_growth = True
#         with tf.Session(config=config) as sess:
#             test(sess, setting)  # 运行测试相关的代码逻辑
#
# # ceshi 完成后，我们重置默认图
#     FLAGS.train = True  # 修改 FLAGS.train 的取值为 T
#
#     # 在这里调用 tf.reset_default_graph() 是安全的，因为我们不在 `tf.Graph().as_default()` 的上下文中
#     tf.reset_default_graph()
#     print("*************第四轮训练开始*****************")
#     if FLAGS.train:
#         # 训练部分，在独立的图上下文中
#         with tf.Graph().as_default():
#             config = tf.ConfigProto(allow_soft_placement=True)
#             config.gpu_options.allow_growth = True
#             with tf.Session(config=config) as sess:
#                 train(sess, setting)  # 训练模型
#
#         # 训练完成后，我们重置默认图
#         FLAGS.train = False  # 修改 FLAGS.train 的取值为 False
#
#     # 在这里调用 tf.reset_default_graph() 是安全的，因为我们不在 `tf.Graph().as_default()` 的上下文中
#     tf.reset_default_graph()
#     print("第四轮测试开始，上天保佑，结果如愿")
#
#     # 测试部分，也在独立的图上下文中
#     with tf.Graph().as_default():
#         config = tf.ConfigProto(allow_soft_placement=True)
#         config.gpu_options.allow_growth = True
#         with tf.Session(config=config) as sess:
#             test(sess, setting)  # 运行测试相关的代码逻辑
#
# # ceshi 完成后，我们重置默认图
#     FLAGS.train = True  # 修改 FLAGS.train 的取值为 T
#
#     # 在这里调用 tf.reset_default_graph() 是安全的，因为我们不在 `tf.Graph().as_default()` 的上下文中
#     tf.reset_default_graph()
#     print("*************第五轮训练开始*****************")
#     if FLAGS.train:
#         # 训练部分，在独立的图上下文中
#         with tf.Graph().as_default():
#             config = tf.ConfigProto(allow_soft_placement=True)
#             config.gpu_options.allow_growth = True
#             with tf.Session(config=config) as sess:
#                 train(sess, setting)  # 训练模型
#
#         # 训练完成后，我们重置默认图
#         FLAGS.train = False  # 修改 FLAGS.train 的取值为 False
#
#     # 在这里调用 tf.reset_default_graph() 是安全的，因为我们不在 `tf.Graph().as_default()` 的上下文中
#     tf.reset_default_graph()
#     print("第五轮测试开始，上天保佑，结果如愿")
#
#     # 测试部分，也在独立的图上下文中
#     with tf.Graph().as_default():
#         config = tf.ConfigProto(allow_soft_placement=True)
#         config.gpu_options.allow_growth = True
#         with tf.Session(config=config) as sess:
#             test(sess, setting)  # 运行测试相关的代码逻辑




if __name__ == '__main__':
    tf.app.run()







